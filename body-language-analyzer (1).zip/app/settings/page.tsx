import Link from "next/link"
import { ArrowLeft, Bell, Eye, Lock, Moon, Volume2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import UserMenu from "@/components/user-menu"

const settingsData = [
  { id: "notifications", icon: Bell, label: "Push Notifications", description: "Receive alerts for new analyses" },
  { id: "darkMode", icon: Moon, label: "Dark Mode", description: "Switch between light and dark themes" },
  { id: "sound", icon: Volume2, label: "Sound Effects", description: "Play sounds during analysis" },
  { id: "privacy", icon: Eye, label: "Privacy Mode", description: "Blur sensitive information in results" },
]

export default function SettingsPage() {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <header className="sticky top-0 z-10 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <Link href="/">
            <Button
              variant="ghost"
              size="icon"
              className="text-energy-600 hover:text-energy-700 hover:bg-energy-50 rounded-xl"
            >
              <ArrowLeft className="h-5 w-5" />
              <span className="sr-only">Back</span>
            </Button>
          </Link>
          <div className="ml-4">
            <h1 className="text-lg font-semibold bg-clip-text text-transparent bg-gradient-to-r from-energy-600 to-insight-600">
              Settings
            </h1>
          </div>
          <UserMenu />
        </div>
      </header>
      <main className="flex-1 container py-6">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-insight-600 via-emotion-600 to-energy-600">
            Application Settings
          </h1>
          <p className="mt-2 text-muted-foreground max-w-2xl mx-auto">
            Customize your nonverbal communication analysis experience
          </p>
        </div>

        <div className="grid gap-6 max-w-2xl mx-auto">
          {settingsData.map((item) => (
            <Card key={item.id} className="p-4 bg-white/50 hover:bg-white/70 transition-colors rounded-2xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-app-purple-light flex items-center justify-center">
                    <item.icon className="w-5 h-5 text-app-purple" />
                  </div>
                  <div>
                    <Label htmlFor={item.id} className="font-semibold text-app-purple-dark">
                      {item.label}
                    </Label>
                    <p className="text-sm text-app-purple-dark/60">{item.description}</p>
                  </div>
                </div>
                <Switch id={item.id} />
              </div>
            </Card>
          ))}

          <Card className="p-4 bg-white/50 hover:bg-white/70 transition-colors rounded-2xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-app-purple-light flex items-center justify-center">
                  <Lock className="w-5 h-5 text-app-purple" />
                </div>
                <div>
                  <h3 className="font-semibold text-app-purple-dark">Change Password</h3>
                  <p className="text-sm text-app-purple-dark/60">Update your account password</p>
                </div>
              </div>
              <Button variant="outline" size="sm" className="rounded-xl">
                Change
              </Button>
            </div>
          </Card>

          <div className="flex justify-end">
            <Button className="rounded-xl bg-app-purple text-white hover:bg-app-purple-dark">Save Changes</Button>
          </div>
        </div>
      </main>
    </div>
  )
}

