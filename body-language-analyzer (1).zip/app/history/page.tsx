import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowLeft, Calendar, Clock, Smile, Frown, Meh } from "lucide-react"
import Link from "next/link"
import UserMenu from "@/components/user-menu"

const historyData = [
  { id: 1, date: "2025-03-01", time: "10:30", duration: "15 min", mood: "Positive", confidence: 85 },
  { id: 2, date: "2025-02-28", time: "14:45", duration: "20 min", mood: "Neutral", confidence: 72 },
  { id: 3, date: "2025-02-27", time: "09:15", duration: "10 min", mood: "Negative", confidence: 68 },
  { id: 4, date: "2025-02-26", time: "16:00", duration: "25 min", mood: "Positive", confidence: 90 },
]

const getMoodIcon = (mood: string) => {
  switch (mood) {
    case "Positive":
      return <Smile className="w-6 h-6 text-green-500" />
    case "Negative":
      return <Frown className="w-6 h-6 text-red-500" />
    default:
      return <Meh className="w-6 h-6 text-yellow-500" />
  }
}

export default function HistoryPage() {
  return (
    <div className="min-h-screen p-6 lg:p-8 bg-app-blue-light">
      <Card className="glass-card max-w-2xl mx-auto p-6">
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="ghost" size="icon" className="rounded-xl">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-app-purple-dark">Analysis History</h1>
          </div>
          <UserMenu />
        </div>

        <div className="space-y-6">
          {historyData.map((item) => (
            <Card key={item.id} className="p-4 bg-white/50 hover:bg-white/70 transition-colors rounded-2xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-app-purple-light flex items-center justify-center">
                    {getMoodIcon(item.mood)}
                  </div>
                  <div>
                    <h3 className="font-semibold text-app-purple-dark">Analysis Session #{item.id}</h3>
                    <div className="flex items-center gap-2 text-sm text-app-purple-dark/60">
                      <Calendar className="w-4 h-4" />
                      <span>{item.date}</span>
                      <Clock className="w-4 h-4 ml-2" />
                      <span>{item.time}</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium text-app-purple-dark">Confidence</div>
                  <div className="text-2xl font-bold text-app-purple">{item.confidence}%</div>
                </div>
              </div>
              <div className="mt-4 flex justify-between items-center">
                <div className="text-sm text-app-purple-dark/60">Duration: {item.duration}</div>
                <Button variant="outline" size="sm" className="rounded-xl">
                  View Details
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </Card>
    </div>
  )
}

