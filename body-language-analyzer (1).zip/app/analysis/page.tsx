"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowLeft, Camera, Mic, PlayCircle, Thermometer, Wind } from "lucide-react"
import Link from "next/link"
import { useState } from "react"
import { Progress } from "@/components/ui/progress"
import UserMenu from "@/components/user-menu"

export default function AnalysisPage() {
  const [confidence, setConfidence] = useState(75)
  const [emotion, setEmotion] = useState("Neutral")
  const [temperature, setTemperature] = useState(28)

  return (
    <div className="min-h-screen p-6 lg:p-8">
      <Card className="glass-card max-w-md mx-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="ghost" size="icon" className="rounded-xl">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-semibold text-app-purple-dark">Body Language Analysis</h1>
          </div>
          <UserMenu />
        </div>

        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <Card className="p-4 bg-app-purple-light/50 rounded-2xl">
              <div className="text-app-purple-dark">
                <p className="text-sm font-medium">Confidence</p>
                <div className="text-3xl font-bold mt-1">{confidence}%</div>
              </div>
              <Progress value={confidence} className="mt-2 bg-app-purple/20">
                <div className="bg-app-purple h-full rounded-full" />
              </Progress>
            </Card>

            <Card className="p-4 bg-app-blue-light/50 rounded-2xl">
              <div className="text-app-blue-dark">
                <p className="text-sm font-medium">Emotion</p>
                <div className="text-3xl font-bold mt-1">{emotion}</div>
              </div>
              <div className="mt-2 flex gap-2">
                <div className="w-2 h-2 rounded-full bg-app-blue/40" />
                <div className="w-2 h-2 rounded-full bg-app-blue" />
                <div className="w-2 h-2 rounded-full bg-app-blue/40" />
              </div>
            </Card>
          </div>

          <Card className="overflow-hidden rounded-2xl aspect-video bg-gradient-to-br from-app-purple-light to-app-blue-light relative">
            <div className="absolute inset-0 flex items-center justify-center">
              <Button size="lg" className="rounded-full w-16 h-16 bg-white/90 hover:bg-white">
                <PlayCircle className="w-8 h-8 text-app-purple" />
              </Button>
            </div>
          </Card>

          <div className="grid grid-cols-3 gap-4">
            <Button variant="outline" className="rounded-xl h-auto py-4 px-3 bg-white/50">
              <div className="space-y-1">
                <Camera className="w-5 h-5 mx-auto text-app-purple" />
                <span className="text-xs font-medium block">Camera</span>
              </div>
            </Button>

            <Button variant="outline" className="rounded-xl h-auto py-4 px-3 bg-white/50">
              <div className="space-y-1">
                <Mic className="w-5 h-5 mx-auto text-app-blue" />
                <span className="text-xs font-medium block">Audio</span>
              </div>
            </Button>

            <Button variant="outline" className="rounded-xl h-auto py-4 px-3 bg-white/50">
              <div className="space-y-1">
                <Wind className="w-5 h-5 mx-auto text-app-pink" />
                <span className="text-xs font-medium block">Gestures</span>
              </div>
            </Button>
          </div>

          <Card className="p-4 bg-gradient-to-r from-app-blue-light to-app-purple-light rounded-2xl">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center">
                <Thermometer className="w-6 h-6 text-app-purple" />
              </div>
              <div className="flex-1">
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-bold text-app-purple-dark">{temperature}°C</span>
                  <span className="text-sm text-app-purple-dark/60">Emotional Temperature</span>
                </div>
                <Progress value={temperature * 2} className="mt-2 bg-white/30">
                  <div className="bg-white h-full rounded-full" />
                </Progress>
              </div>
            </div>
          </Card>
        </div>
      </Card>
    </div>
  )
}

