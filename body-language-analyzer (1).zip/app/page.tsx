import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Brain, Camera, History, MessageSquare, Settings } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import UserMenu from "@/components/user-menu"

export default function HomePage() {
  return (
    <div className="min-h-screen p-6 lg:p-8">
      <Card className="glass-card max-w-md mx-auto p-6">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold text-app-purple-dark">Welcome Back!</h1>
            <p className="text-app-purple-dark/60">Ready to analyze your communication?</p>
          </div>
          <UserMenu />
        </div>

        <div className="space-y-6">
          <div>
            <h2 className="text-lg font-semibold text-app-purple-dark mb-4">Analysis Tools</h2>
            <div className="grid grid-cols-2 gap-4">
              <Link href="/analysis" className="block">
                <Card className="feature-card p-4 bg-app-purple-light/50">
                  <div className="isometric-icon w-12 h-12 mb-3 bg-app-purple rounded-2xl flex items-center justify-center">
                    <Brain className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-medium text-app-purple-dark">Body Language</h3>
                  <p className="text-sm text-app-purple-dark/60">Start analysis</p>
                </Card>
              </Link>

              <Link href="/speech" className="block">
                <Card className="feature-card p-4 bg-app-blue-light/50">
                  <div className="isometric-icon w-12 h-12 mb-3 bg-app-blue rounded-2xl flex items-center justify-center">
                    <MessageSquare className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-medium text-app-blue-dark">Speech Analysis</h3>
                  <p className="text-sm text-app-blue-dark/60">Start analysis</p>
                </Card>
              </Link>

              <Link href="/history" className="block">
                <Card className="feature-card p-4 bg-app-pink-light/50">
                  <div className="isometric-icon w-12 h-12 mb-3 bg-app-pink rounded-2xl flex items-center justify-center">
                    <History className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-medium text-app-pink-dark">History</h3>
                  <p className="text-sm text-app-pink-dark/60">View past sessions</p>
                </Card>
              </Link>

              <Link href="/settings" className="block">
                <Card className="feature-card p-4 bg-app-yellow-light/50">
                  <div className="isometric-icon w-12 h-12 mb-3 bg-app-yellow rounded-2xl flex items-center justify-center">
                    <Settings className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-medium text-app-yellow-dark">Settings</h3>
                  <p className="text-sm text-app-yellow-dark/60">Configure app</p>
                </Card>
              </Link>
            </div>
          </div>

          <div>
            <h2 className="text-lg font-semibold text-app-purple-dark mb-4">Quick Actions</h2>
            <Card className="feature-card p-4 bg-gradient-to-r from-app-blue-light to-app-purple-light">
              <div className="flex items-center gap-4">
                <div className="isometric-icon w-12 h-12 bg-white rounded-2xl flex items-center justify-center">
                  <Camera className="w-6 h-6 text-app-purple" />
                </div>
                <div className="flex-1">
                  <h3 className="font-medium text-app-purple-dark">Start New Session</h3>
                  <p className="text-sm text-app-purple-dark/60">Begin real-time analysis</p>
                </div>
                <Button size="sm" className="bg-app-purple text-white hover:bg-app-purple-dark">
                  Start
                </Button>
              </div>
            </Card>
          </div>
        </div>

        <div className="absolute top-[-120px] right-[-80px] pointer-events-none">
          <Image
            src="/placeholder.svg?height=200&width=200"
            alt="Decorative element"
            width={200}
            height={200}
            className="opacity-20"
          />
        </div>

        <div className="absolute bottom-[-100px] left-[-60px] pointer-events-none">
          <Image
            src="/placeholder.svg?height=160&width=160"
            alt="Decorative element"
            width={160}
            height={160}
            className="opacity-20"
          />
        </div>
      </Card>
    </div>
  )
}

