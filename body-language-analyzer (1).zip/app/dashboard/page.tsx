import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Image from "next/image"

export default function DashboardPage() {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <header className="sticky top-0 z-10 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <Link href="/">
            <Button variant="ghost" size="icon" className="text-emotion-600 hover:text-emotion-700 hover:bg-emotion-50">
              <ArrowLeft className="h-5 w-5" />
              <span className="sr-only">Back</span>
            </Button>
          </Link>
          <div className="ml-4">
            <h1 className="text-lg font-semibold bg-clip-text text-transparent bg-gradient-to-r from-emotion-600 to-energy-600">
              Analysis Dashboard
            </h1>
          </div>
        </div>
      </header>
      <main className="flex-1 container py-6">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-insight-600 via-emotion-600 to-energy-600">
            Communication Insights Dashboard
          </h1>
          <p className="mt-2 text-muted-foreground max-w-2xl mx-auto">
            Track your nonverbal communication patterns and gain insights to improve your interpersonal skills
          </p>
        </div>

        <div className="grid gap-6">
          <div className="grid gap-4 md:grid-cols-3">
            <Card className="border-2 border-insight-100 shadow-lg analysis-card">
              <CardHeader className="pb-2 bg-gradient-to-r from-insight-50 to-insight-100">
                <CardTitle className="text-sm font-medium text-insight-800 flex items-center gap-2">
                  <Image
                    src="/placeholder.svg?height=20&width=20"
                    alt="Total Analyses"
                    width={20}
                    height={20}
                    className="opacity-70"
                  />
                  Total Analyses
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="text-3xl font-bold text-insight-700">24</div>
                <p className="text-xs text-muted-foreground">+4 from last week</p>
              </CardContent>
            </Card>
            <Card className="border-2 border-emotion-100 shadow-lg analysis-card">
              <CardHeader className="pb-2 bg-gradient-to-r from-emotion-50 to-emotion-100">
                <CardTitle className="text-sm font-medium text-emotion-800 flex items-center gap-2">
                  <Image
                    src="/placeholder.svg?height=20&width=20"
                    alt="Average Duration"
                    width={20}
                    height={20}
                    className="opacity-70"
                  />
                  Average Duration
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="text-3xl font-bold text-emotion-700">4.5 min</div>
                <p className="text-xs text-muted-foreground">-0.5 min from last week</p>
              </CardContent>
            </Card>
            <Card className="border-2 border-energy-100 shadow-lg analysis-card">
              <CardHeader className="pb-2 bg-gradient-to-r from-energy-50 to-energy-100">
                <CardTitle className="text-sm font-medium text-energy-800 flex items-center gap-2">
                  <Image
                    src="/placeholder.svg?height=20&width=20"
                    alt="Most Common Mood"
                    width={20}
                    height={20}
                    className="opacity-70"
                  />
                  Most Common Mood
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="text-3xl font-bold text-energy-700">Neutral</div>
                <p className="text-xs text-muted-foreground">Previously: Positive</p>
              </CardContent>
            </Card>
          </div>

          <Card className="border-2 border-insight-100 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-insight-50 to-insight-100">
              <CardTitle className="text-insight-800">Analysis Trends</CardTitle>
              <CardDescription>View your body language and speech patterns over time</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="body">
                <TabsList className="grid w-full grid-cols-2 bg-insight-100">
                  <TabsTrigger
                    value="body"
                    className="data-[state=active]:bg-white data-[state=active]:text-insight-800"
                  >
                    Body Language
                  </TabsTrigger>
                  <TabsTrigger
                    value="speech"
                    className="data-[state=active]:bg-white data-[state=active]:text-insight-800"
                  >
                    Speech
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="body" className="space-y-4 mt-4">
                  <div className="h-[300px] flex items-center justify-center bg-insight-50 rounded-md relative overflow-hidden">
                    <Image
                      src="/placeholder.svg?height=200&width=500"
                      alt="Body language trend chart"
                      width={500}
                      height={200}
                      className="opacity-70"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <p className="text-muted-foreground bg-white/80 px-4 py-2 rounded-md">
                        Body language trend chart would appear here
                      </p>
                    </div>
                  </div>
                  <div className="grid gap-4 md:grid-cols-3">
                    <Card className="border-2 border-insight-100">
                      <CardHeader className="pb-2 bg-insight-50">
                        <CardTitle className="text-sm font-medium text-insight-800 flex items-center gap-2">
                          <Image
                            src="/placeholder.svg?height=16&width=16"
                            alt="Posture"
                            width={16}
                            height={16}
                            className="opacity-70"
                          />
                          Most Common Posture
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="pt-3">
                        <div className="text-xl font-bold text-insight-700">Relaxed</div>
                        <p className="text-xs text-muted-foreground">42% of analyses</p>
                      </CardContent>
                    </Card>
                    <Card className="border-2 border-insight-100">
                      <CardHeader className="pb-2 bg-insight-50">
                        <CardTitle className="text-sm font-medium text-insight-800 flex items-center gap-2">
                          <Image
                            src="/placeholder.svg?height=16&width=16"
                            alt="Expression"
                            width={16}
                            height={16}
                            className="opacity-70"
                          />
                          Most Common Expression
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="pt-3">
                        <div className="text-xl font-bold text-insight-700">Neutral</div>
                        <p className="text-xs text-muted-foreground">38% of analyses</p>
                      </CardContent>
                    </Card>
                    <Card className="border-2 border-insight-100">
                      <CardHeader className="pb-2 bg-insight-50">
                        <CardTitle className="text-sm font-medium text-insight-800 flex items-center gap-2">
                          <Image
                            src="/placeholder.svg?height=16&width=16"
                            alt="Gesture"
                            width={16}
                            height={16}
                            className="opacity-70"
                          />
                          Most Common Gesture
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="pt-3">
                        <div className="text-xl font-bold text-insight-700">Hand movement</div>
                        <p className="text-xs text-muted-foreground">45% of analyses</p>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>
                <TabsContent value="speech" className="space-y-4 mt-4">
                  <div className="h-[300px] flex items-center justify-center bg-insight-50 rounded-md relative overflow-hidden">
                    <Image
                      src="/placeholder.svg?height=200&width=500"
                      alt="Speech trend chart"
                      width={500}
                      height={200}
                      className="opacity-70"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <p className="text-muted-foreground bg-white/80 px-4 py-2 rounded-md">
                        Speech trend chart would appear here
                      </p>
                    </div>
                  </div>
                  <div className="grid gap-4 md:grid-cols-3">
                    <Card className="border-2 border-insight-100">
                      <CardHeader className="pb-2 bg-insight-50">
                        <CardTitle className="text-sm font-medium text-insight-800 flex items-center gap-2">
                          <Image
                            src="/placeholder.svg?height=16&width=16"
                            alt="Tone"
                            width={16}
                            height={16}
                            className="opacity-70"
                          />
                          Most Common Tone
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="pt-3">
                        <div className="text-xl font-bold text-insight-700">Calm</div>
                        <p className="text-xs text-muted-foreground">35% of analyses</p>
                      </CardContent>
                    </Card>
                    <Card className="border-2 border-insight-100">
                      <CardHeader className="pb-2 bg-insight-50">
                        <CardTitle className="text-sm font-medium text-insight-800 flex items-center gap-2">
                          <Image
                            src="/placeholder.svg?height=16&width=16"
                            alt="Pace"
                            width={16}
                            height={16}
                            className="opacity-70"
                          />
                          Most Common Pace
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="pt-3">
                        <div className="text-xl font-bold text-insight-700">Moderate</div>
                        <p className="text-xs text-muted-foreground">48% of analyses</p>
                      </CardContent>
                    </Card>
                    <Card className="border-2 border-insight-100">
                      <CardHeader className="pb-2 bg-insight-50">
                        <CardTitle className="text-sm font-medium text-insight-800 flex items-center gap-2">
                          <Image
                            src="/placeholder.svg?height=16&width=16"
                            alt="Keywords"
                            width={16}
                            height={16}
                            className="opacity-70"
                          />
                          Top Keywords
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="pt-3">
                        <div className="text-xl font-bold text-insight-700">consider, believe</div>
                        <p className="text-xs text-muted-foreground">Used in 60% of analyses</p>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          <div className="grid gap-6 md:grid-cols-2">
            <Card className="border-2 border-emotion-100 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-emotion-50 to-emotion-100">
                <CardTitle className="text-emotion-800">Communication Strengths</CardTitle>
                <CardDescription>Areas where your nonverbal communication excels</CardDescription>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="space-y-4">
                  <div className="flex items-center gap-3 p-3 bg-emotion-50 rounded-md">
                    <div className="h-10 w-10 rounded-full bg-emotion-100 flex items-center justify-center">
                      <Image
                        src="/placeholder.svg?height=24&width=24"
                        alt="Strength 1"
                        width={24}
                        height={24}
                        className="opacity-70"
                      />
                    </div>
                    <div>
                      <h3 className="font-medium text-emotion-800">Consistent Eye Contact</h3>
                      <p className="text-sm text-muted-foreground">
                        You maintain strong eye contact in 85% of analyses
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-3 bg-emotion-50 rounded-md">
                    <div className="h-10 w-10 rounded-full bg-emotion-100 flex items-center justify-center">
                      <Image
                        src="/placeholder.svg?height=24&width=24"
                        alt="Strength 2"
                        width={24}
                        height={24}
                        className="opacity-70"
                      />
                    </div>
                    <div>
                      <h3 className="font-medium text-emotion-800">Clear Speech Pace</h3>
                      <p className="text-sm text-muted-foreground">
                        Your speech pace is consistently moderate and clear
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-3 bg-emotion-50 rounded-md">
                    <div className="h-10 w-10 rounded-full bg-emotion-100 flex items-center justify-center">
                      <Image
                        src="/placeholder.svg?height=24&width=24"
                        alt="Strength 3"
                        width={24}
                        height={24}
                        className="opacity-70"
                      />
                    </div>
                    <div>
                      <h3 className="font-medium text-emotion-800">Expressive Hand Gestures</h3>
                      <p className="text-sm text-muted-foreground">
                        You use appropriate hand gestures to emphasize points
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 border-energy-100 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-energy-50 to-energy-100">
                <CardTitle className="text-energy-800">Areas for Improvement</CardTitle>
                <CardDescription>Aspects of your communication that could be enhanced</CardDescription>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="space-y-4">
                  <div className="flex items-center gap-3 p-3 bg-energy-50 rounded-md">
                    <div className="h-10 w-10 rounded-full bg-energy-100 flex items-center justify-center">
                      <Image
                        src="/placeholder.svg?height=24&width=24"
                        alt="Improvement 1"
                        width={24}
                        height={24}
                        className="opacity-70"
                      />
                    </div>
                    <div>
                      <h3 className="font-medium text-energy-800">Posture Consistency</h3>
                      <p className="text-sm text-muted-foreground">
                        Your posture tends to become tense during longer conversations
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-3 bg-energy-50 rounded-md">
                    <div className="h-10 w-10 rounded-full bg-energy-100 flex items-center justify-center">
                      <Image
                        src="/placeholder.svg?height=24&width=24"
                        alt="Improvement 2"
                        width={24}
                        height={24}
                        className="opacity-70"
                      />
                    </div>
                    <div>
                      <h3 className="font-medium text-energy-800">Facial Expressions</h3>
                      <p className="text-sm text-muted-foreground">
                        Your facial expressions could be more varied to match your speech
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-3 bg-energy-50 rounded-md">
                    <div className="h-10 w-10 rounded-full bg-energy-100 flex items-center justify-center">
                      <Image
                        src="/placeholder.svg?height=24&width=24"
                        alt="Improvement 3"
                        width={24}
                        height={24}
                        className="opacity-70"
                      />
                    </div>
                    <div>
                      <h3 className="font-medium text-energy-800">Filler Words</h3>
                      <p className="text-sm text-muted-foreground">
                        You use filler words like "um" and "uh" frequently
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

