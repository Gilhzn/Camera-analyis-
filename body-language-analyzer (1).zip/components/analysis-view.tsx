"use client"

import { useEffect, useRef, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Camera,
  Mic,
  PauseCircle,
  PlayCircle,
  Save,
  Brain,
  Activity,
  MessageSquare,
  Smile,
  Frown,
  Meh,
} from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import Image from "next/image"

type Analysis = {
  bodyLanguage: {
    posture: string
    facialExpression: string
    gestures: string
    confidence: number
  }
  speech: {
    tone: string
    pace: string
    keywords: string[]
    confidence: number
  }
  overallMood: string
  timestamp: Date
}

export default function AnalysisView() {
  const { toast } = useToast()
  const videoRef = useRef<HTMLVideoElement>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [hasPermission, setHasPermission] = useState<boolean | null>(null)
  const [currentAnalysis, setCurrentAnalysis] = useState<Analysis | null>(null)
  const [analysisHistory, setAnalysisHistory] = useState<Analysis[]>([])

  useEffect(() => {
    // Simulating analysis results for demo purposes
    if (isAnalyzing) {
      const interval = setInterval(() => {
        const newAnalysis: Analysis = {
          bodyLanguage: {
            posture: ["Relaxed", "Tense", "Open", "Closed"][Math.floor(Math.random() * 4)],
            facialExpression: ["Neutral", "Happy", "Concerned", "Surprised"][Math.floor(Math.random() * 4)],
            gestures: ["Hand movement", "Head nodding", "Crossing arms", "Fidgeting"][Math.floor(Math.random() * 4)],
            confidence: Math.floor(Math.random() * 30) + 70,
          },
          speech: {
            tone: ["Confident", "Hesitant", "Excited", "Calm"][Math.floor(Math.random() * 4)],
            pace: ["Fast", "Moderate", "Slow", "Variable"][Math.floor(Math.random() * 4)],
            keywords: ["important", "consider", "believe", "actually"].filter(() => Math.random() > 0.5),
            confidence: Math.floor(Math.random() * 30) + 70,
          },
          overallMood: ["Neutral", "Positive", "Negative", "Mixed"][Math.floor(Math.random() * 4)],
          timestamp: new Date(),
        }
        setCurrentAnalysis(newAnalysis)
      }, 2000)

      return () => clearInterval(interval)
    }
  }, [isAnalyzing])

  const requestPermissions = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true })

      if (videoRef.current) {
        videoRef.current.srcObject = stream
      }

      setHasPermission(true)
      setIsAnalyzing(true)

      toast({
        title: "Analysis started",
        description: "Real-time body language and speech analysis is now active.",
      })
    } catch (error) {
      console.error("Error accessing media devices:", error)
      setHasPermission(false)
      toast({
        title: "Permission denied",
        description: "Please allow access to camera and microphone to use this feature.",
        variant: "destructive",
      })
    }
  }

  const toggleAnalysis = () => {
    if (isAnalyzing) {
      setIsAnalyzing(false)
    } else if (hasPermission) {
      setIsAnalyzing(true)
    } else {
      requestPermissions()
    }
  }

  const saveAnalysis = () => {
    if (currentAnalysis) {
      setAnalysisHistory((prev) => [currentAnalysis, ...prev])
      toast({
        title: "Analysis saved",
        description: "The current analysis has been saved to your history.",
      })
    }
  }

  const getMoodColor = (mood: string) => {
    switch (mood) {
      case "Positive":
        return "green"
      case "Negative":
        return "red"
      case "Mixed":
        return "amber"
      default:
        return "blue"
    }
  }

  return (
    <div className="container py-6">
      <div className="mb-8 text-center relative">
        <h1 className="text-4xl font-bold tracking-tight text-theme-800 mb-2">Nonverbal Communication Analyzer</h1>
        <p className="mt-2 text-theme-600 max-w-2xl mx-auto">
          Analyze body language and speech patterns in real-time to gain insights into nonverbal communication cues
        </p>
        <div className="absolute top-0 left-0 -translate-x-1/2 -translate-y-1/2">
          <Image
            src="/placeholder.svg?height=100&width=100"
            alt="Decorative element"
            width={100}
            height={100}
            className="opacity-20"
          />
        </div>
        <div className="absolute bottom-0 right-0 translate-x-1/2 translate-y-1/2">
          <Image
            src="/placeholder.svg?height=80&width=80"
            alt="Decorative element"
            width={80}
            height={80}
            className="opacity-20"
          />
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="theme-card glassmorphism">
          <CardHeader className="theme-header">
            <CardTitle className="flex items-center justify-between text-theme-800">
              <span className="flex items-center gap-2">
                <Camera className="h-5 w-5 text-theme-600" />
                Live Camera Feed
              </span>
              {hasPermission === false && <Badge variant="destructive">Permission Denied</Badge>}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0 aspect-video bg-theme-100/50 relative overflow-hidden">
            {hasPermission ? (
              <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
            ) : (
              <div className="flex flex-col items-center justify-center h-full p-6 bg-gradient-to-b from-theme-100/50 to-white/50">
                <Image
                  src="/placeholder.svg?height=120&width=120"
                  alt="Camera access"
                  width={120}
                  height={120}
                  className="mb-4 opacity-80"
                />
                <p className="mb-4 text-center text-theme-600">
                  Enable camera and microphone access to analyze body language and speech in real-time
                </p>
                <Button onClick={requestPermissions} className="gap-2 bg-theme-600 hover:bg-theme-700 text-white">
                  <Camera className="h-4 w-4" />
                  <Mic className="h-4 w-4" />
                  Enable Camera & Microphone
                </Button>
              </div>
            )}
            <div className="absolute bottom-4 right-4 flex gap-2">
              <Button
                variant="secondary"
                size="icon"
                onClick={toggleAnalysis}
                disabled={hasPermission === false}
                className={
                  isAnalyzing
                    ? "bg-theme-200 text-theme-800 hover:bg-theme-300"
                    : "bg-theme-100 text-theme-800 hover:bg-theme-200"
                }
              >
                {isAnalyzing ? <PauseCircle className="h-5 w-5" /> : <PlayCircle className="h-5 w-5" />}
              </Button>
              <Button
                variant="secondary"
                size="icon"
                onClick={saveAnalysis}
                disabled={!currentAnalysis}
                className="bg-theme-100 text-theme-800 hover:bg-theme-200"
              >
                <Save className="h-5 w-5" />
              </Button>
            </div>
            {isAnalyzing && (
              <div className="absolute top-4 left-4">
                <Badge variant="outline" className="bg-theme-100 text-theme-800 border-theme-300 animate-pulse">
                  Recording
                </Badge>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="grid gap-6">
          <Card className="theme-card glassmorphism analysis-card">
            <CardHeader className="theme-header">
              <CardTitle className="flex items-center gap-2 text-theme-800">
                <Brain className="h-5 w-5 text-theme-600" />
                Real-time Analysis
              </CardTitle>
              <CardDescription className="text-theme-600">Body language and speech analysis results</CardDescription>
            </CardHeader>
            <CardContent className="p-4">
              {!isAnalyzing && !currentAnalysis ? (
                <Alert className="bg-theme-100/50 border-theme-300">
                  <AlertDescription className="flex items-center gap-2 text-theme-700">
                    <Activity className="h-4 w-4 text-theme-600" />
                    Start the analysis to see real-time results here.
                  </AlertDescription>
                </Alert>
              ) : (
                <Tabs defaultValue="body">
                  <TabsList className="grid w-full grid-cols-2 bg-theme-100/50">
                    <TabsTrigger
                      value="body"
                      className="data-[state=active]:bg-white/50 data-[state=active]:text-theme-800"
                    >
                      Body Language
                    </TabsTrigger>
                    <TabsTrigger
                      value="speech"
                      className="data-[state=active]:bg-white/50 data-[state=active]:text-theme-800"
                    >
                      Speech
                    </TabsTrigger>
                  </TabsList>
                  <TabsContent value="body" className="space-y-4 mt-4">
                    {currentAnalysis && (
                      <>
                        <div className="space-y-3">
                          <div className="flex justify-between items-center p-2 rounded-md bg-theme-100/50">
                            <span className="text-sm font-medium flex items-center gap-2 text-theme-700">
                              <Image
                                src="/placeholder.svg?height=24&width=24"
                                alt="Posture"
                                width={24}
                                height={24}
                                className="opacity-70"
                              />
                              Posture
                            </span>
                            <Badge variant="outline" className="bg-white/50 text-theme-700 border-theme-300">
                              {currentAnalysis.bodyLanguage.posture}
                            </Badge>
                          </div>
                          <div className="flex justify-between items-center p-2 rounded-md bg-theme-100/50">
                            <span className="text-sm font-medium flex items-center gap-2 text-theme-700">
                              <Image
                                src="/placeholder.svg?height=24&width=24"
                                alt="Facial Expression"
                                width={24}
                                height={24}
                                className="opacity-70"
                              />
                              Facial Expression
                            </span>
                            <Badge variant="outline" className="bg-white/50 text-theme-700 border-theme-300">
                              {currentAnalysis.bodyLanguage.facialExpression}
                            </Badge>
                          </div>
                          <div className="flex justify-between items-center p-2 rounded-md bg-theme-100/50">
                            <span className="text-sm font-medium flex items-center gap-2 text-theme-700">
                              <Image
                                src="/placeholder.svg?height=24&width=24"
                                alt="Gestures"
                                width={24}
                                height={24}
                                className="opacity-70"
                              />
                              Gestures
                            </span>
                            <Badge variant="outline" className="bg-white/50 text-theme-700 border-theme-300">
                              {currentAnalysis.bodyLanguage.gestures}
                            </Badge>
                          </div>
                          <div className="space-y-1 p-2 rounded-md bg-theme-100/50">
                            <div className="flex justify-between text-theme-700">
                              <span className="text-sm font-medium">Confidence</span>
                              <span className="text-sm">{currentAnalysis.bodyLanguage.confidence}%</span>
                            </div>
                            <Progress
                              value={currentAnalysis.bodyLanguage.confidence}
                              className="h-2 bg-theme-200/50"
                              indicatorClassName="bg-theme-600"
                            />
                          </div>
                        </div>
                      </>
                    )}
                  </TabsContent>
                  <TabsContent value="speech" className="space-y-4 mt-4">
                    {currentAnalysis && (
                      <>
                        <div className="space-y-3">
                          <div className="flex justify-between items-center p-2 rounded-md bg-theme-100/50">
                            <span className="text-sm font-medium flex items-center gap-2 text-theme-700">
                              <Image
                                src="/placeholder.svg?height=24&width=24"
                                alt="Tone"
                                width={24}
                                height={24}
                                className="opacity-70"
                              />
                              Tone
                            </span>
                            <Badge variant="outline" className="bg-white/50 text-theme-700 border-theme-300">
                              {currentAnalysis.speech.tone}
                            </Badge>
                          </div>
                          <div className="flex justify-between items-center p-2 rounded-md bg-theme-100/50">
                            <span className="text-sm font-medium flex items-center gap-2 text-theme-700">
                              <Image
                                src="/placeholder.svg?height=24&width=24"
                                alt="Pace"
                                width={24}
                                height={24}
                                className="opacity-70"
                              />
                              Pace
                            </span>
                            <Badge variant="outline" className="bg-white/50 text-theme-700 border-theme-300">
                              {currentAnalysis.speech.pace}
                            </Badge>
                          </div>
                          <div className="flex justify-between items-center p-2 rounded-md bg-theme-100/50">
                            <span className="text-sm font-medium flex items-center gap-2 text-theme-700">
                              <Image
                                src="/placeholder.svg?height=24&width=24"
                                alt="Keywords"
                                width={24}
                                height={24}
                                className="opacity-70"
                              />
                              Keywords
                            </span>
                            <div className="flex flex-wrap gap-1 justify-end">
                              {currentAnalysis.speech.keywords.map((keyword, i) => (
                                <Badge
                                  key={i}
                                  variant="outline"
                                  className="bg-white/50 text-theme-700 border-theme-300"
                                >
                                  {keyword}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          <div className="space-y-1 p-2 rounded-md bg-theme-100/50">
                            <div className="flex justify-between text-theme-700">
                              <span className="text-sm font-medium">Confidence</span>
                              <span className="text-sm">{currentAnalysis.speech.confidence}%</span>
                            </div>
                            <Progress
                              value={currentAnalysis.speech.confidence}
                              className="h-2 bg-theme-200/50"
                              indicatorClassName="bg-theme-600"
                            />
                          </div>
                        </div>
                      </>
                    )}
                  </TabsContent>
                </Tabs>
              )}
            </CardContent>
          </Card>

          <Card className="theme-card glassmorphism analysis-card">
            <CardHeader className="theme-header">
              <CardTitle className="flex items-center gap-2 text-theme-800">
                <MessageSquare className="h-5 w-5 text-theme-600" />
                Overall Assessment
              </CardTitle>
              <CardDescription className="text-theme-600">
                Combined analysis of body language and speech
              </CardDescription>
            </CardHeader>
            <CardContent>
              {currentAnalysis ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-center py-4">
                    <div className="relative">
                      <Image
                        src="/placeholder.svg?height=100&width=100"
                        alt={currentAnalysis.overallMood}
                        width={100}
                        height={100}
                        className="opacity-70 mb-2"
                      />
                      <Badge className="text-lg px-4 py-2 absolute bottom-0 left-1/2 transform -translate-x-1/2 bg-theme-100/50 text-theme-800 border-theme-300">
                        {currentAnalysis.overallMood}
                      </Badge>
                      {currentAnalysis.overallMood === "Positive" && (
                        <Smile className="absolute top-0 right-0 h-6 w-6 text-green-500" />
                      )}
                      {currentAnalysis.overallMood === "Negative" && (
                        <Frown className="absolute top-0 right-0 h-6 w-6 text-red-500" />
                      )}
                      {currentAnalysis.overallMood === "Neutral" && (
                        <Meh className="absolute top-0 right-0 h-6 w-6 text-yellow-500" />
                      )}
                    </div>
                  </div>
                  <div className="text-sm text-theme-600 text-center">
                    Last updated: {currentAnalysis.timestamp.toLocaleTimeString()}
                  </div>
                </div>
              ) : (
                <Alert className="bg-theme-100/50 border-theme-300">
                  <AlertDescription className="flex items-center gap-2 text-theme-700">
                    <Activity className="h-4 w-4 text-theme-600" />
                    Start the analysis to see the overall assessment.
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {analysisHistory.length > 0 && (
        <div className="mt-8">
          <Card className="theme-card glassmorphism">
            <CardHeader className="theme-header">
              <CardTitle className="flex items-center gap-2 text-theme-800">
                <History className="h-5 w-5 text-theme-600" />
                Recent Analysis History
              </CardTitle>
              <CardDescription>Your last {Math.min(3, analysisHistory.length)} saved analyses</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analysisHistory.slice(0, 3).map((analysis, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0 hover:bg-theme-100/50 p-2 rounded-md transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-theme-100/50 flex items-center justify-center">
                        <span className="text-theme-600 font-bold text-sm">#{analysisHistory.length - index}</span>
                      </div>
                      <div>
                        <div className="font-medium">Analysis #{analysisHistory.length - index}</div>
                        <div className="text-sm text-theme-600">{analysis.timestamp.toLocaleString()}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge
                        className={`bg-${getMoodColor(analysis.overallMood)}-100/50 text-${getMoodColor(analysis.overallMood)}-800 border-${getMoodColor(analysis.overallMood)}-200`}
                      >
                        {analysis.overallMood}
                      </Badge>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-theme-200 text-theme-700 hover:bg-theme-100/50"
                      >
                        View Details
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <div className="mt-8 grid gap-6 md:grid-cols-3">
        <Card className="theme-card glassmorphism analysis-card">
          <CardContent className="p-0">
            <div className="p-6 text-center">
              <div className="mx-auto w-16 h-16 mb-4 rounded-full bg-theme-100/50 flex items-center justify-center">
                <Image
                  src="/placeholder.svg?height=40&width=40"
                  alt="Body Language"
                  width={40}
                  height={40}
                  className="opacity-70"
                />
              </div>
              <h3 className="text-lg font-medium text-theme-800">Body Language Analysis</h3>
              <p className="mt-2 text-sm text-theme-600">
                Analyze posture, gestures, and facial expressions to understand nonverbal cues
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="theme-card glassmorphism analysis-card">
          <CardContent className="p-0">
            <div className="p-6 text-center">
              <div className="mx-auto w-16 h-16 mb-4 rounded-full bg-theme-100/50 flex items-center justify-center">
                <Image
                  src="/placeholder.svg?height=40&width=40"
                  alt="Speech Analysis"
                  width={40}
                  height={40}
                  className="opacity-70"
                />
              </div>
              <h3 className="text-lg font-medium text-theme-800">Speech Pattern Analysis</h3>
              <p className="mt-2 text-sm text-theme-600">
                Detect tone, pace, and key phrases to understand verbal communication style
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="theme-card glassmorphism analysis-card">
          <CardContent className="p-0">
            <div className="p-6 text-center">
              <div className="mx-auto w-16 h-16 mb-4 rounded-full bg-theme-100/50 flex items-center justify-center">
                <Image
                  src="/placeholder.svg?height=40&width=40"
                  alt="Emotional Intelligence"
                  width={40}
                  height={40}
                  className="opacity-70"
                />
              </div>
              <h3 className="text-lg font-medium text-theme-800">Emotional Intelligence</h3>
              <p className="mt-2 text-sm text-theme-600">
                Gain insights into emotional states and improve your communication skills
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

